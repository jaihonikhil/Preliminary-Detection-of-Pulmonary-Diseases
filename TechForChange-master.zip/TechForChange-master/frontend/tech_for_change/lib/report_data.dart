
class DataReport{
  String result;
  String date;
  String age;
  String gender;
  double weight;
  double height;
  double bmi;
  String symptoms;
  String remarks;

  DataReport({this.result, this.date, this.age, this.gender, this.weight, this.height, this.bmi, this.symptoms, this.remarks});
}